#include <stdlib.h>

typedef struct address
{
    int number;
    int offset;
} add;

add addext(int _rline);
int getAdd(add _addin);